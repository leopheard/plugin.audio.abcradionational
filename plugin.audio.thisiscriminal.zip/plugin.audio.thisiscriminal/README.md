plugin.audio.thisiscriminal
=============================

KODI / XBMC addon for the audio podcast 'Criminal' from NPR / PRX

Criminal is a podcast about crime. Not so much the "if it bleeds, it leads," kind of crime. Something a little more complex. Stories of people who've done wrong, been wronged, and/or gotten caught somewhere in the middle. We are a proud member of Radiotopia, from PRX, a curated network of extraordinary, story-driven shows. Learn more at radiotopia.fm

www.thisiscriminal.com
#CriminalShow
#ThisisCriminal
#Criminalpodcast
#Criminal podcast

<a href="https://www.thisiscriminal.co,"><img src="https://thisiscriminal.com/wp-content/themes/criminal-theme/assets/images/Criminal_SocialShare_1.png" alt="Criminal podcast">
